'use client';

import React, { useState } from 'react';
import { Dialog } from '@/components/ui/Dialog';
import { Button } from '@/components/ui/Button';
import { TableContainer, Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/Table';

interface CsvImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportSuccess?: () => void;
}

interface ParsedRow {
  team_name: string;
  team_code: string;
  student_name: string;
  roll_number: string;
  email: string;
  isValid: boolean;
  error?: string;
}

export const CsvImportModal: React.FC<CsvImportModalProps> = ({
  isOpen,
  onClose,
  onImportSuccess,
}) => {
  const [parsedRows, setParsedRows] = useState<ParsedRow[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [importSummary, setImportSummary] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    setImportSummary(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      parseCsvText(text);
    };
    reader.readAsText(selectedFile);
  };

  const parseCsvText = (text: string) => {
    const lines = text.split(/\r\n|\n/).filter((l) => l.trim().length > 0);
    if (lines.length <= 1) {
      setParsedRows([]);
      return;
    }

    // First line is the header row - skip it
    const rows: ParsedRow[] = [];

    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(',').map((c) => c.trim());
      if (cols.length < 2) continue;

      const team_name = cols[0] || '';
      const team_code = cols[1] || '';
      const student_name = cols[2] || '';
      const roll_number = cols[3] || '';
      const email = cols[4] || '';

      const isValid = Boolean(team_name && team_code);
      const error = !isValid ? 'Missing mandatory Team Name or SIH Code' : undefined;

      rows.push({
        team_name,
        team_code,
        student_name,
        roll_number,
        email,
        isValid,
        error,
      });
    }

    setParsedRows(rows);
  };

  const handleConfirmImport = async () => {
    const validRows = parsedRows.filter((r) => r.isValid);
    if (validRows.length === 0) return;

    setIsProcessing(true);
    try {
      // Send rows to server action API
      const res = await fetch('/api/admin/import-teams', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rows: validRows }),
      });

      if (res.ok) {
        setImportSummary(`Successfully imported ${validRows.length} team records!`);
        if (onImportSuccess) onImportSuccess();
      } else {
        const data = await res.json();
        setImportSummary(`Import failed: ${data.error || 'Server error'}`);
      }
    } catch (err) {
      setImportSummary(`Import failed: ${err instanceof Error ? err.message : 'Unknown error'}`);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Dialog
      isOpen={isOpen}
      onClose={onClose}
      title="Bulk Team & Student CSV Import"
      description="Upload an Excel/CSV file with headers: team_name, team_code, student_name, roll_number, email"
      size="lg"
      footer={
        <>
          <Button variant="ghost" size="sm" onClick={onClose} disabled={isProcessing}>
            Cancel
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={handleConfirmImport}
            disabled={parsedRows.length === 0 || isProcessing}
            isLoading={isProcessing}
          >
            Confirm Import ({parsedRows.filter((r) => r.isValid).length} Valid)
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-sm space-y-2">
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600">
            Select CSV File:
          </label>
          <input
            type="file"
            accept=".csv, .txt"
            onChange={handleFileChange}
            className="text-xs text-slate-600 file:mr-3 file:py-1.5 file:px-3 file:rounded file:border-0 file:text-xs file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
          />
        </div>

        {importSummary && (
          <div className="p-3 rounded bg-blue-50 border border-blue-200 text-xs font-medium text-blue-800">
            {importSummary}
          </div>
        )}

        {parsedRows.length > 0 && (
          <div className="space-y-2">
            <span className="text-xs font-semibold text-slate-700">
              CSV Preview & Validation ({parsedRows.length} Rows Detected):
            </span>
            <TableContainer className="max-h-60 overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>SIH Code</TableHead>
                    <TableHead>Team Name</TableHead>
                    <TableHead>Student Name</TableHead>
                    <TableHead>Roll No.</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {parsedRows.map((row, idx) => (
                    <TableRow key={idx}>
                      <TableCell className="font-mono text-xs text-blue-600">{row.team_code}</TableCell>
                      <TableCell className="font-semibold text-slate-900">{row.team_name}</TableCell>
                      <TableCell className="text-xs text-slate-600">{row.student_name || '—'}</TableCell>
                      <TableCell className="font-mono text-xs text-slate-500">{row.roll_number || '—'}</TableCell>
                      <TableCell>
                        {row.isValid ? (
                          <span className="text-xs font-bold text-emerald-400">✓ Valid</span>
                        ) : (
                          <span className="text-xs font-bold text-rose-400">{row.error}</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </div>
        )}
      </div>
    </Dialog>
  );
};
